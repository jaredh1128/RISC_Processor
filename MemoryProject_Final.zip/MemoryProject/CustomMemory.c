

//==============================================================================
//
// Title:		CustomMemory
// Purpose:		A short description of the application.
//
// Created on:	9/20/2018 at 6:39:17 PM by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

//==============================================================================
// Include files

#include <ansi_c.h>
#include <cvirte.h>		
#include <userint.h>
#include "CustomMemory.h"
#include "toolbox.h"
#include "CustomMemory_Util.h"
#include <formatio.h>
#include <rs232.h>
#include "progressbar.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// Static global variables

static int main_panelHandle = 0;
static int tab_panelHandle1;
static int tab_panelHandle2;  

//==============================================================================
// Static functions

//==============================================================================
// Global variables

DefineThreadSafeVar(thread_flags, T_Flags);
int threadpoolHandle;
int comreadQHandle;
int parsemsgQHandle;
int consoleQHandle;


int comread_threadID;
int parsemsg_threadID;
int console_threadID;

int RS232Error;

u8 str_input[33];

serial_cfg_t SerialCFG;
header_t Header = {0xCA,0x01,0x00,0xCB};
body_t Body = {0x0000};
//==============================================================================
// Global functions

/// HIFN The main entry-point function.
int main (int argc, char *argv[])
{
	int error = 0;
	
	/* initialize and load resources */
	nullChk (InitCVIRTE (0, argv, 0));
	errChk (main_panelHandle = LoadPanel (0, "CustomMemory.uir", PANEL));
	GetPanelHandleFromTabPage (main_panelHandle, PANEL_TABS, 0, &tab_panelHandle1);
	GetPanelHandleFromTabPage (main_panelHandle, PANEL_TABS, 1, &tab_panelHandle2);
	ProgressBar_ConvertFromSlide (tab_panelHandle1, TABPANEL_1_PROGRESSBAR_SERIAL);
	CmtNewThreadPool(MAX_THREADS, &threadpoolHandle);
	
	InitializeT_Flags();
	
	/* display the panel and run the user interface */
	errChk (DisplayPanel (main_panelHandle));
	errChk (RunUserInterface ());

Error:
	/* clean up */
	if (main_panelHandle > 0)
		DiscardPanel (main_panelHandle);
	return 0;
}

//==============================================================================
// UI callback function prototypes

/// HIFN Exit when the user dismisses the panel.



//////////////////////////////////////////////////////////////
//******************* Thread Functions **********************/
//////////////////////////////////////////////////////////////

void SetConnectedFlag(int state)
{
	thread_flags *tflag = GetPointerToT_Flags();
	tflag->iConnectedFlag = state;
	ReleasePointerToT_Flags();
}

int GetConnectedFlag(void)
{
	thread_flags *tflag = GetPointerToT_Flags();
	int state = tflag->iConnectedFlag;
	ReleasePointerToT_Flags();
	return state;
}

void SetSentMsgFlag(int state)
{
	thread_flags *tflag = GetPointerToT_Flags();
	tflag->iMsgSentFlag = state;
	ReleasePointerToT_Flags();
}

int GetSentMsgFlag(void)
{
	thread_flags *tflag = GetPointerToT_Flags();
	int state = tflag->iMsgSentFlag;
	ReleasePointerToT_Flags();
	return state;
}
	
void ShutDownThreads(void)
{
	CmtFlushTSQ(comreadQHandle, TSQ_FLUSH_ALL, NULL);
	CmtFlushTSQ(parsemsgQHandle, TSQ_FLUSH_ALL, NULL);
	CmtFlushTSQ(consoleQHandle, TSQ_FLUSH_ALL, NULL);
	
	CmtDiscardTSQ(comreadQHandle);
	CmtDiscardTSQ(parsemsgQHandle);
	CmtDiscardTSQ(consoleQHandle);
	
	if(comread_threadID > 0)
		CmtWaitForThreadPoolFunctionCompletionEx(threadpoolHandle, comread_threadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING, 1000);
	if(parsemsg_threadID > 0)
		CmtWaitForThreadPoolFunctionCompletionEx(threadpoolHandle, parsemsg_threadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING, 1000);
	if(console_threadID > 0)
		CmtWaitForThreadPoolFunctionCompletionEx(threadpoolHandle, comread_threadID, OPT_TP_PROCESS_EVENTS_WHILE_WAITING, 1000);
	
}


//////////////////////////////////////////////////////////////
//**************** Convenience Functions ********************/
//////////////////////////////////////////////////////////////

void GetSerialConfig(void)
{
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_COM_PORT, &SerialCFG.iComID);
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_BAUD_RATE, &SerialCFG.iBaudRate);
	GetCtrlIndex(tab_panelHandle1, TABPANEL_1_CFG_PARITY_BITS, &SerialCFG.iParityBits);
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_DATA_BITS, &SerialCFG.iDataBits);
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_STOP_BITS, &SerialCFG.iStopBits);
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_INPUT_QUEUE, &SerialCFG.iInputQueueSize);
	GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, &SerialCFG.iOutputQueueSize);
}

void DimSerialConfig(u8 dim_val)
{
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_BAUD_RATE, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_PARITY_BITS, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_DATA_BITS, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_STOP_BITS, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_INPUT_QUEUE, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, ATTR_DIMMED, dim_val);
	
}

void DimConsoleConfig(u8 dim_val)
{
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_FLUSH_INQ, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_FLUSH_OUTQ, ATTR_DIMMED, dim_val);
	SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_TIMEOUT, ATTR_DIMMED, dim_val);
}


void DisplayRS232Error (void)
{
    char ErrorMessage[200];
    switch (RS232Error)
        {
        default :
            if (RS232Error < 0)
                {  
                Fmt (ErrorMessage, "%s<RS232 error number %i", RS232Error);
                MessagePopup ("RS232 Message", ErrorMessage);
                }
            break;
        case 0  :
            MessagePopup ("RS232 Message", "No errors.");
            break;
		case -1	:
			MessagePopup ("RS232 Message", "Unknown system error");
			break;
        case -2 :
            Fmt (ErrorMessage, "%s", "Invalid port number (must be in the "
                                     "range 1 to 8).");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        case -3 :
            Fmt (ErrorMessage, "%s", "No port is open.\n"
                 "Check COM Port setting in Configure.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
		case -4	:
            MessagePopup ("RS232 Message", "Unknown I/O error");
			break;
		case -5 :
            MessagePopup ("RS232 Message", "Unexpected internal error");
			break;
		case -6 :
            MessagePopup ("RS232 Message", "No port found");
			break;
		case -7 :
			MessagePopup ("RS232 Message", "Port already in use");
			break;
		case -14:
			MessagePopup ("RS232 Message", "Invalid baud rate");
			break;
		case -24:
			MessagePopup ("RS232 Message", "Invalid parity");
			break;
		case -34:
			MessagePopup ("RS232 Message", "Invalid data bits");
			break;
		case -44:
			MessagePopup ("RS232 Message", "Invalid stop bits");
			break;
        case -99 :
            Fmt (ErrorMessage, "%s", "Timeout error.\n\n"
                 "Either increase timeout value,\n"
                 "       check COM Port setting, or\n"
                 "       check device.");
            MessagePopup ("RS232 Message", ErrorMessage);
            break;
        }
}

void Update_Header(void)
{
	char SoH[3], cmd[3], payload[3], chksm[3];
							  
	Header.start_of_header = 0xCA;
	Header.command_id = 0x01;
	Header.payload_len = strlen(str_input);
	Header.chksum = Header.start_of_header + Header.command_id + Header.payload_len;
	
	
	sprintf(SoH,"%02X",Header.start_of_header);
	sprintf(cmd,"%02X",Header.command_id);
	sprintf(payload,"%02X",Header.payload_len);
	sprintf(chksm,"%02X",Header.chksum);
	
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_START_OF_HEADER, SoH);
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_COMMAND_ID, cmd);
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_PAYLOAD_LENGTH, payload);
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_HEADER_CHKSUM, chksm);
	
}


int Pack_U8(u8 *buffer, u8 byte)
{
	int i = 0;
	buffer[i++] = byte;
	return i;
}

int Pack_U16(u8 *buffer, u16 halfword)
{
	
	int i = 0;
	buffer[i++] = halfword >> 8;
	buffer[i++] = halfword  & 0xFF;
	return i;
}

void Update_Body_Checksum(void)
{
	u16 body_chksum = 0;
	char str_body_chksum[5]; 
	
	for(int i = 0; i < strlen(str_input); i++)
	{
		body_chksum += str_input[i];
	}
	
	Body.checksum = body_chksum;
	sprintf(str_body_chksum, "%04X",body_chksum);	
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_BODY_CHECKSUM, str_body_chksum);
}

void Encode_Base16(u8 *strinput)
{
	char encoded_output[MAX_INPUT_LENGTH] = "";
	for(int i = 0; i < strlen(strinput); i++)
	{
		char temp[3] = "";
		sprintf(temp, "%02X", strinput[i]);
		strcat(encoded_output, temp);
	}
			
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_ENCODED_RESULT, encoded_output);
}

void ReadComPort(void)
{
	int bytes_read, inQLen;
	u8 buf[MAX_BUFFER_LENGTH];
	
		inQLen = GetInQLen(SerialCFG.iComID);
		if(inQLen != 0)
		{
		bytes_read = ComRd(SerialCFG.iComID, buf, inQLen);
		
		CmtWriteTSQData(comreadQHandle, buf, bytes_read, TSQ_INFINITE_TIMEOUT, NULL);
		}
}

void ParseMessage(void)
{
	u8 buf[MAX_BUFFER_LENGTH]; 
	int index = 0;
	int found_header = 0;
	int message_parsed = 0;
	int completed = 0;
	u8 start_of_header = 0xCA;
	u8 payload_len;
	u8 parsed_msg[MAX_BUFFER_LENGTH] = "";
	
	static u8 comparison[MAX_BUFFER_LENGTH] = "";
	
	
	int bytes_read = CmtReadTSQData(comreadQHandle, buf, MAX_BUFFER_LENGTH, 0,NULL);
	
	if(bytes_read != 0 && bytes_read >= 26 && GetSentMsgFlag())
	{
		while(completed == 0 && message_parsed == 0 && index < (MAX_BUFFER_LENGTH-MAX_PACKET_SIZE))
		{
			if(found_header == 0)
			{
				if(buf[index] == start_of_header)
				{
					found_header = 1;
					index++;
				}
				else
					index++;
			}
			else
			{
				payload_len = buf[index++];
				for(int i = 0; i < payload_len; i++)
				{
					parsed_msg[i] = buf[index++];
				}
				
				message_parsed = 1;
			}
			
		}
		if(message_parsed && completed == 0)
		{
			if(strcmp(comparison,parsed_msg) == 0)
			{
				SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_ENCODED_RESULT,parsed_msg);
				completed = 1;
				SetSentMsgFlag(FALSE);
			}
			else
			{
				strcpy(comparison,parsed_msg);
			}
		}
	}
	
}

void UpdateConsole(void)
{
	u8 buf[MAX_BUFFER_LENGTH];
	char text_box[MAX_BUFFER_LENGTH];
	
	int bytes_read = CmtReadTSQData(consoleQHandle, buf, 32, 0 ,NULL);
	if(strlen(buf)%32 > 0)
	{
		strcat(buf,"\n");
	}
	if(bytes_read != 0)
	{
		 SetCtrlVal(tab_panelHandle1, TABPANEL_1_WINDOW_CONSOLE, buf);
	}
}

int UpdateResult(void)
{
	char result[MAX_BUFFER_LENGTH] = "";
	CmtReadTSQData(parsemsgQHandle, result, 24, 0,NULL);
	SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_ENCODED_RESULT,result);
	return 1;
}

//////////////////////////////////////////////////////////////
//****************** Callback Functions *********************/
//////////////////////////////////////////////////////////////

int CVICALLBACK panelCB (int panel, int event, void *callbackData,
		int eventData1, int eventData2)
{
	switch(event)
	{
		case EVENT_CLOSE:
			QuitUserInterface(0);
			break;
		case EVENT_KEYPRESS:
			if(eventData1 == VAL_ESC_VKEY)
				QuitUserInterface(0);
			break;
	}
	return 0;
}

int CVICALLBACK SerialConnect (int panel, int control, int event,
							   void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			GetSerialConfig();
			DisableBreakOnLibraryErrors();
			RS232Error = OpenComConfig(SerialCFG.iComID, NULL,  SerialCFG.iBaudRate, SerialCFG.iParityBits, SerialCFG.iDataBits, SerialCFG.iStopBits, SerialCFG.iInputQueueSize, SerialCFG.iOutputQueueSize);
			EnableBreakOnLibraryErrors();
			if (RS232Error) 
				DisplayRS232Error();
			else
			{
				SetConnectedFlag(TRUE);
				SetSentMsgFlag(FALSE);
				printf("Event thread: %d\n", CmtGetCurrentThreadID());
				
				CmtNewTSQ(4*MAX_BUFFER_LENGTH,sizeof(u8),NULL, &comreadQHandle);
				CmtNewTSQ(4*MAX_BUFFER_LENGTH,sizeof(u8),NULL, &parsemsgQHandle);
				CmtNewTSQ(4*MAX_BUFFER_LENGTH,sizeof(u8),NULL, &consoleQHandle);

				CmtScheduleThreadPoolFunction(threadpoolHandle, ComReadThreadFunction,NULL, &comread_threadID); 
				CmtScheduleThreadPoolFunction(threadpoolHandle, ParseMsgThreadFunction,NULL, &parsemsg_threadID); 
				//CmtScheduleThreadPoolFunction(threadpoolHandle, UpdateConsoleThreadFunction,NULL, &console_threadID); 
				
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_STATUS_CONNECTION,ATTR_TEXT_COLOR, VAL_GREEN);
				SetCtrlVal(tab_panelHandle1, TABPANEL_1_STATUS_CONNECTION, "Connected");
				ProgressBar_SetPercentage(tab_panelHandle1, TABPANEL_1_PROGRESSBAR_SERIAL, 100, NULL);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_CONNECT, ATTR_DIMMED, TRUE);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_DISCONNECT, ATTR_DIMMED, FALSE);
				DimConsoleConfig(FALSE);
				DimSerialConfig(TRUE);
			}
			break;
	}
	return 0;
}

int CVICALLBACK ComReadThreadFunction(void* functionData)
{
	printf("Com Thread: %d\n",CmtGetCurrentThreadID());
	CmtFlushTSQ(comreadQHandle,TSQ_FLUSH_ALL, NULL);
	while(GetConnectedFlag())
	{
		ReadComPort();
	}
	return 1;
}

int CVICALLBACK ParseMsgThreadFunction(void* functionData)
{
	printf("Parse Thread: %d\n", CmtGetCurrentThreadID());
	CmtFlushTSQ(parsemsgQHandle,TSQ_FLUSH_ALL, NULL);
	while(GetConnectedFlag())
	{
		ParseMessage();
	}
	return 1;
}


int CVICALLBACK UpdateConsoleThreadFunction(void* functionData)
{
	printf("Console Thread: %d\n", CmtGetCurrentThreadID());
	CmtFlushTSQ(consoleQHandle,TSQ_FLUSH_ALL, NULL);
	while(GetConnectedFlag())
	{
		UpdateConsole();
	}
	
	return 1;
}

int CVICALLBACK SerialDisconnect (int panel, int control, int event,
								  void *callbackData, int eventData1, int eventData2)
{
	int error = 0;
	switch (event)
	{
		case EVENT_COMMIT:
			RS232Error = CloseCom(SerialCFG.iComID);
			if (RS232Error)
				DisplayRS232Error();
			else
			{
				SetConnectedFlag(FALSE);
				SetSentMsgFlag(FALSE);
				ShutDownThreads();
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_STATUS_CONNECTION,ATTR_TEXT_COLOR, VAL_GRAY);
				SetCtrlVal(tab_panelHandle1, TABPANEL_1_STATUS_CONNECTION, "Disconnected");
				ProgressBar_SetPercentage(tab_panelHandle1, TABPANEL_1_PROGRESSBAR_SERIAL, 0, NULL);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_CONNECT, ATTR_DIMMED, FALSE);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CMD_DISCONNECT, ATTR_DIMMED, TRUE);
				DimConsoleConfig(TRUE);
				DimSerialConfig(FALSE);
			}
			break;
	}
	
	return 0;
}

int CVICALLBACK OutQueue_Toggle (int panel, int control, int event,
								 void *callbackData, int eventData1, int eventData2)
{
	int iDisabled;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_DISABLE_OUTQ, &iDisabled);
			if(iDisabled)
			{
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, ATTR_MIN_VALUE, -1);
				SetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, -1);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, ATTR_DIMMED, 1);
			}
			else
			{
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, ATTR_MIN_VALUE, 0);
				DefaultCtrl(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE);
				SetCtrlAttribute(tab_panelHandle1, TABPANEL_1_CFG_OUTPUT_QUEUE, ATTR_DIMMED, 0);
			}
			
			break;
	}
	return 0;
}


int CVICALLBACK Flush_InQ (int panel, int control, int event,
						   void *callbackData, int eventData1, int eventData2)
{
	int error = 0;
	switch (event)
	{
		case EVENT_COMMIT:
			errChk(FlushInQ(SerialCFG.iComID));
			MessagePopup("Success", "Input queue flushed successfully!");
			break;
	}
Error:
	if (error != 0)
		MessagePopup("Error", "Unable to flush input queue!");
	return 0;
}


int CVICALLBACK Flush_OutQ (int panel, int control, int event,
							void *callbackData, int eventData1, int eventData2)
{
	int error = 0;
	switch (event)
	{
		case EVENT_COMMIT:
			errChk(FlushOutQ(SerialCFG.iComID));
			MessagePopup("Success", "Output queue flushed successfully!");
			break;
	}
Error:
	if(error != 0)
		MessagePopup("Error", "Unable to flush output queue!");
	return 0;
}

int CVICALLBACK Change_Timeout (int panel, int control, int event,
								void *callbackData, int eventData1, int eventData2)
{
	double iTimeout;
	switch (event)
	{
		case EVENT_COMMIT:
			GetCtrlVal(tab_panelHandle1, TABPANEL_1_CFG_TIMEOUT, &iTimeout);
			SetComTime(SerialCFG.iComID, iTimeout);
			break;
	}
	return 0;
}

int CVICALLBACK Event_InputChanged (int panel, int control, int event,
									void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_VAL_CHANGED:
			GetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_INPUT_MESSAGE, str_input);
			Update_Header();
			Update_Body_Checksum();
			
			break;
	}
	return 0;
}

int CVICALLBACK Send_MSG (int panel, int control, int event,
						  void *callbackData, int eventData1, int eventData2)
{
	int index = 0, total_bytes = HEADER_SIZE + Header.payload_len, updating = 0;
	u8 output_buffer[MAX_BUFFER_LENGTH];
	char bytes_sent[50];
				

	switch (event)
	{
		case EVENT_COMMIT:
			
			index += Pack_U8(&output_buffer[index], Header.start_of_header);
			index += Pack_U8(&output_buffer[index], Header.payload_len);
;
			
			for(int i = 0; i < strlen(str_input); i++)
			{
				index += Pack_U8(&output_buffer[index], str_input[i]);
			}

			if(GetConnectedFlag())
			{
				for(int i = 0; i < index; i++)
				{
					ComWrtByte(SerialCFG.iComID,output_buffer[i]);
					
				}
				
				SetSentMsgFlag(TRUE);
				sprintf(bytes_sent, "%d bytes sent successfully out of %d bytes", index, total_bytes);
				SetCtrlVal(tab_panelHandle2,TABPANEL_2_STATUS_BYTES_SENT, bytes_sent);
			}
			
			else
			{
				sprintf(bytes_sent, "Message transmission failed!");
				SetCtrlVal(tab_panelHandle2,TABPANEL_2_STATUS_BYTES_SENT, bytes_sent);
			}
			
			break;
			
	}
	return 0;
				
}

int CVICALLBACK Clear_Fields (int panel, int control, int event,
							  void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_INPUT_MESSAGE, 0);
			SetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_ENCODED_RESULT, 0);	
			GetCtrlVal(tab_panelHandle2,TABPANEL_2_CFG_INPUT_MESSAGE, str_input);
			Update_Header();
			Update_Body_Checksum();

			break;
	}
	return 0;
}
