/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1       /* callback function: panelCB */
#define  PANEL_TABS                       2       /* control type: tab, callback function: (none) */

     /* tab page panel controls */
#define  TABPANEL_1_CFG_COM_PORT          2       /* control type: ring, callback function: (none) */
#define  TABPANEL_1_CMD_DISCONNECT        3       /* control type: command, callback function: SerialDisconnect */
#define  TABPANEL_1_CMD_CONNECT           4       /* control type: command, callback function: SerialConnect */
#define  TABPANEL_1_LABEL_SERIAL          5       /* control type: textMsg, callback function: (none) */
#define  TABPANEL_1_PROGRESSBAR_SERIAL    6       /* control type: scale, callback function: (none) */
#define  TABPANEL_1_DECOR_SERIAL          7       /* control type: deco, callback function: (none) */
#define  TABPANEL_1_CFG_PARITY_BITS       8       /* control type: ring, callback function: (none) */
#define  TABPANEL_1_CFG_OUTPUT_QUEUE      9       /* control type: numeric, callback function: (none) */
#define  TABPANEL_1_CFG_INPUT_QUEUE       10      /* control type: numeric, callback function: (none) */
#define  TABPANEL_1_CFG_BAUD_RATE         11      /* control type: numeric, callback function: (none) */
#define  TABPANEL_1_CFG_STOP_BITS         12      /* control type: ring, callback function: (none) */
#define  TABPANEL_1_CFG_DATA_BITS         13      /* control type: ring, callback function: (none) */
#define  TABPANEL_1_CFG_DISABLE_OUTQ      14      /* control type: radioButton, callback function: OutQueue_Toggle */
#define  TABPANEL_1_WINDOW_CONSOLE        15      /* control type: textBox, callback function: (none) */
#define  TABPANEL_1_CMD_CLEAR_CONSOLE     16      /* control type: command, callback function: (none) */
#define  TABPANEL_1_CMD_FLUSH_INQ         17      /* control type: command, callback function: Flush_InQ */
#define  TABPANEL_1_LABEL_CONFIG          18      /* control type: textMsg, callback function: (none) */
#define  TABPANEL_1_STATUS_CONNECTION     19      /* control type: textMsg, callback function: (none) */
#define  TABPANEL_1_CMD_FLUSH_OUTQ        20      /* control type: command, callback function: Flush_OutQ */
#define  TABPANEL_1_LABEL_CONNECTION_STAT 21      /* control type: textMsg, callback function: (none) */
#define  TABPANEL_1_DECOR_CONSOLE         22      /* control type: deco, callback function: (none) */
#define  TABPANEL_1_CFG_TERMINATION_BYTE  23      /* control type: ring, callback function: (none) */
#define  TABPANEL_1_DECOR_CONFIG          24      /* control type: deco, callback function: (none) */
#define  TABPANEL_1_CFG_TIMEOUT           25      /* control type: numeric, callback function: Change_Timeout */
#define  TABPANEL_1_LABEL_CONSOLE         26      /* control type: textMsg, callback function: (none) */

     /* tab page panel controls */
#define  TABPANEL_2_CFG_INPUT_MESSAGE     2       /* control type: string, callback function: Event_InputChanged */
#define  TABPANEL_2_CFG_ENCODED_RESULT    3       /* control type: string, callback function: (none) */
#define  TABPANEL_2_CMD_CLEAR_ALL         4       /* control type: command, callback function: Clear_Fields */
#define  TABPANEL_2_CFG_START_OF_HEADER   5       /* control type: string, callback function: (none) */
#define  TABPANEL_2_CFG_PAYLOAD_LENGTH    6       /* control type: string, callback function: (none) */
#define  TABPANEL_2_CFG_COMMAND_ID        7       /* control type: string, callback function: (none) */
#define  TABPANEL_2_CFG_HEADER_CHKSUM     8       /* control type: string, callback function: (none) */
#define  TABPANEL_2_DECOR_HEADER          9       /* control type: deco, callback function: (none) */
#define  TABPANEL_2_CFG_BODY_CHECKSUM     10      /* control type: string, callback function: (none) */
#define  TABPANEL_2_LABEL_HEADER          11      /* control type: textMsg, callback function: (none) */
#define  TABPANEL_2_DECORATION            12      /* control type: deco, callback function: (none) */
#define  TABPANEL_2_CMD_SEND              13      /* control type: command, callback function: Send_MSG */
#define  TABPANEL_2_LABEL_BODY_STATUS     14      /* control type: textMsg, callback function: (none) */
#define  TABPANEL_2_STATUS_BYTES_SENT     15      /* control type: textMsg, callback function: (none) */


     /* Control Arrays: */

          /* (no control arrays in the resource file) */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK Change_Timeout(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Clear_Fields(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Event_InputChanged(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Flush_InQ(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Flush_OutQ(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK OutQueue_Toggle(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK panelCB(int panel, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK Send_MSG(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SerialConnect(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK SerialDisconnect(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
