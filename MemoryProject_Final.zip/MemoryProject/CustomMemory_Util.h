//==============================================================================
//
// Title:		CustomMemory_Util.h
// Purpose:		A short description of the interface.
//
// Created on:	9/20/2018 at 11:38:20 PM by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

#ifndef __CustomMemory_Util_H__
#define __CustomMemory_Util_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
#include "common_util.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables

//==============================================================================
// Global functions

typedef struct
{
	int iComID;
	int iBaudRate;
	int iParityBits;
	int iDataBits;
	int iStopBits;
	int iInputQueueSize;
	int iOutputQueueSize;

}serial_cfg_t;


typedef struct
{
	u8 start_of_header;
	u8 command_id;
	u8 payload_len;
	u8 chksum;
}header_t;

typedef struct
{
	u16 checksum;
}body_t;

typedef struct
{
	int iConnectedFlag;
	int iMsgSentFlag;
	
}thread_flags;


void SetConnectedFlag(int state);
int GetConnectedFlag(void);
void SetSentMsgFlag(int state);
int GetSentMsgFlag(void);


void GetSerialConfig(void);
void DimSerialConfig(u8 dim_val);
void DimConsoleConfig(u8 dim_val);
void DisplayRS232Error (void);
void Update_Header(void);
int Pack_U8(u8* buffer, u8 byte);
int Pack_U16(u8 *buffer, u16 halfword);
void Update_Body_Checksum(void);
void Encode_Base16(u8 *strinput);
int UpdateResult(void);
void ShutDownThreads(void);

void ReadComPort(void);
void ParseMessage(void);
void UpdateConsole(void);



int CVICALLBACK ComReadThreadFunction(void* functionData);
int CVICALLBACK ParseMsgThreadFunction(void* functionData);
int CVICALLBACK UpdateConsoleThreadFunction(void* functionData);

#ifdef __cplusplus
    }
#endif

#endif  /* ndef __CustomMemory_Util_H__ */
