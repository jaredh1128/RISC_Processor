//==============================================================================
//
// Title:		common_util.h
// Purpose:		A short description of the interface.
//
// Created on:	9/24/2018 at 8:21:59 PM by .
// Copyright:	. All Rights Reserved.
//
//==============================================================================

#ifndef __common_util_H__
#define __common_util_H__

#ifdef __cplusplus
    extern "C" {
#endif

//==============================================================================
// Include files

#include "cvidef.h"
#include "stdint.h"

//==============================================================================
// Constants

//==============================================================================
// Types

//==============================================================================
// External variables

//==============================================================================
// Global functions

		
#define FALSE				0
#define TRUE				1
#define MAX_BUFFER_LENGTH 	3000
#define HEADER_SIZE			2
#define BODY_CHECKSUM_SIZE 	2
#define	MAX_INPUT_LENGTH	60
#define	MAX_PACKET_SIZE		30
		
		
//Threading//
#define MAX_THREADS			5

		
typedef uint8_t  u8;
typedef uint16_t u16;
typedef uint32_t u32;


		
#ifdef __cplusplus
    }
#endif

#endif  /* ndef __common_util_H__ */
